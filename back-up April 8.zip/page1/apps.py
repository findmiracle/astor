from django.apps import AppConfig


class Page1Config(AppConfig):
    name = 'page1'
